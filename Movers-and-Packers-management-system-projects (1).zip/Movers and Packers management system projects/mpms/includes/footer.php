    <div class="agileinfo_copy_right">
        <div class="container">
            <div class="agileinfo_copy_right_left">
                <p>© 2019 Movers & Packers Management System</p>
            </div>
            <div class="agileinfo_copy_right_right">
                <ul class="social">
                    <li><a class="social-linkedin" href="#">
                        <i></i>
                        <div class="tooltip"><span>Facebook</span></div>
                        </a></li>
                    <li><a class="social-twitter" href="#">
                        <i></i>
                        <div class="tooltip"><span>Twitter</span></div>
                        </a></li>
                    <li><a class="social-google" href="#">
                        <i></i>
                        <div class="tooltip"><span>Google+</span></div>
                        </a></li>
                    <li><a class="social-facebook" href="#">
                        <i></i>
                        <div class="tooltip"><span>Pinterest</span></div>
                        </a></li>
                    <li><a class="social-instagram" href="#">
                        <i></i>
                        <div class="tooltip"><span>Instagram</span></div>
                        </a></li>
                </ul>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>